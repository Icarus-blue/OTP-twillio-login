import React from 'react';

function HomePage() {
    const fontstyle = {
        color: 'white'
    }
    return (
        <div>
            <h1 style={fontstyle}>Login success , hello constumer</h1>
        </div>
    );
}

export default HomePage;